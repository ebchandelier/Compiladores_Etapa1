int main(void) {

	initMe();

	while(isRunning()==1){

		//debud
		printf("get %d\n", yylex());
		//printf("number of lines: %d\n", getLineNumber());
		//printf("::::: %d\n", ht_get( hashtable, "eduardo" ));
			
	}
		
	return 0;
}
